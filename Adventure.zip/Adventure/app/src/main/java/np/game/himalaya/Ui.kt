package np.game.himalaya

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BgTop = Color(0xFF0B1220)
private val BgBottom = Color(0xFF1B2A41)
private val Amber = Color(0xFFFFC857)
private val Panel = Color(0x14FFFFFF)
private val Soft = Color(0xFFB8C4D6)
private val TextMain = Color(0xFFE6ECF5)

@Composable
fun GameApp(state: GameState) {
    var inGame by remember { mutableStateOf(false) }
    BackHandler(enabled = inGame) { inGame = false }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
    ) {
        if (inGame) {
            GameScreen(state) { inGame = false }
        } else {
            MenuScreen(
                state,
                onNew = { state.newGame(); inGame = true },
                onContinue = { inGame = true }
            )
        }
    }
}

@Composable
private fun GameButton(
    text: String,
    onClick: () -> Unit,
    filled: Boolean,
    enabled: Boolean = true
) {
    val shape = RoundedCornerShape(16.dp)
    val m = Modifier
        .fillMaxWidth()
        .heightIn(min = 56.dp)
    if (filled) {
        Button(
            onClick = onClick,
            enabled = enabled,
            shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = Amber,
                contentColor = Color(0xFF1A1A1A),
                disabledContainerColor = Color(0x33FFFFFF),
                disabledContentColor = Color(0x88FFFFFF)
            ),
            modifier = m
        ) { Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center) }
    } else {
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            shape = shape,
            border = BorderStroke(1.dp, if (enabled) Color(0x66FFFFFF) else Color(0x22FFFFFF)),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = Color.White,
                disabledContentColor = Color(0x66FFFFFF)
            ),
            modifier = m
        ) { Text(text, fontSize = 17.sp, textAlign = TextAlign.Center) }
    }
}

@Composable
private fun MenuScreen(state: GameState, onNew: () -> Unit, onContinue: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("⛰️", fontSize = 72.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            "हिमालय की घंटी",
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "एक कहानी जिसमें हर फ़ैसला तुम्हारा है",
            fontSize = 16.sp,
            color = Soft,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(40.dp))
        if (state.canContinue) {
            GameButton("जारी रखें", onContinue, filled = true)
            Spacer(Modifier.height(12.dp))
            GameButton("नया खेल", onNew, filled = false)
        } else {
            GameButton("खेल शुरू करो", onNew, filled = true)
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "खोजे गए अंत: ${state.endings.size} / ${Story.endingCount}",
            fontSize = 14.sp,
            color = Amber
        )
    }
}

@Composable
private fun GameScreen(state: GameState, onMenu: () -> Unit) {
    val hpColor = if (state.hp < 30) Color(0xFFE5484D) else if (state.hp < 60) Amber else Color(0xFF4CC38A)

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "‹ मेनू",
                    fontSize = 15.sp,
                    color = Amber,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onMenu() }
                        .padding(vertical = 6.dp, horizontal = 4.dp)
                )
                Spacer(Modifier.weight(1f))
                Text("ताक़त ${state.hp}", fontSize = 14.sp, color = Color.White)
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = state.hp / 100f,
                color = hpColor,
                trackColor = Color(0x22FFFFFF),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
            )
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (state.items.isEmpty()) {
                    Text("🎒 थैला खाली है", fontSize = 13.sp, color = Soft)
                } else {
                    state.items.forEach { item ->
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Panel)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) { Text("🎒 $item", fontSize = 13.sp, color = Color.White) }
                    }
                }
            }
        }

        Crossfade(
            targetState = state.sceneId,
            modifier = Modifier.weight(1f),
            animationSpec = tween(350)
        ) { id ->
            val scene = Story.scenes[id] ?: Story.scenes.getValue(Story.START)
            SceneBody(state, scene, onMenu)
        }
    }
}

@Composable
private fun SceneBody(state: GameState, scene: Scene, onMenu: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (state.lastNote.isNotEmpty()) {
            Text(state.lastNote, fontSize = 14.sp, color = Amber, textAlign = TextAlign.Center)
        }
        Box(
            Modifier
                .size(96.dp)
                .background(Panel, CircleShape),
            contentAlignment = Alignment.Center
        ) { Text(scene.emoji, fontSize = 52.sp) }

        Text(
            scene.title,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Panel)
                .padding(18.dp)
        ) {
            Text(scene.text, fontSize = 18.sp, lineHeight = 28.sp, color = TextMain)
        }

        val ending = scene.ending
        if (ending != null) {
            val label = when (ending) {
                Ending.WIN -> "🎉 जीत"
                Ending.SECRET -> "🌟 गुप्त अंत"
                Ending.NEUTRAL -> "🏠 अधूरा अंत"
                Ending.LOSE -> "❄️ हार"
            }
            Text(label, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Amber)
            Text(
                "खोजे गए अंत: ${state.endings.size} / ${Story.endingCount}",
                fontSize = 14.sp,
                color = Soft
            )
            GameButton("फिर से खेलें", { state.newGame() }, filled = true)
            GameButton("मेनू", onMenu, filled = false)
        } else {
            val visible = scene.choices.filter { c ->
                val lo = c.hpAtLeast
                val hi = c.hpBelow
                (lo == null || state.hp >= lo) && (hi == null || state.hp < hi)
            }
            visible.forEach { c ->
                val need = c.needs
                val ok = need == null || need in state.items
                val label = if (ok || need == null) c.text else c.text + "  (" + need + " चाहिए)"
                GameButton(label, { state.choose(c) }, filled = false, enabled = ok)
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}
