package np.game.himalaya

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Everything the player has: where they are, their strength, their bag. Saved on the phone. */
class GameState(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("adventure", Context.MODE_PRIVATE)

    var sceneId by mutableStateOf(Story.START)
    var hp by mutableIntStateOf(100)
    var items by mutableStateOf<Set<String>>(emptySet())
    var endings by mutableStateOf<Set<String>>(emptySet())
    var lastNote by mutableStateOf("")
    var started by mutableStateOf(false)

    init {
        load()
    }

    val canContinue: Boolean
        get() = started && Story.scenes[sceneId]?.ending == null

    fun newGame() {
        sceneId = Story.START
        hp = 100
        items = emptySet()
        lastNote = ""
        started = true
        save()
    }

    fun choose(c: Choice) {
        val need = c.needs
        if (need != null && need !in items) return
        val notes = ArrayList<String>()
        if (c.hp != 0) notes.add("ताक़त " + (if (c.hp > 0) "+" else "") + c.hp)
        for (g in c.give) notes.add(g + " मिला")
        for (t in c.take) notes.add(t + " खर्च हुआ")
        items = (items + c.give) - c.take.toSet()
        hp = (hp + c.hp).coerceIn(0, 100)
        sceneId = if (hp <= 0) "end_frozen" else c.next
        lastNote = notes.joinToString("  ·  ")
        if (Story.scenes[sceneId]?.ending != null) endings = endings + sceneId
        save()
    }

    private fun load() {
        val s = prefs.getString("scene", Story.START) ?: Story.START
        sceneId = if (Story.scenes[s] != null) s else Story.START
        hp = prefs.getInt("hp", 100)
        items = (prefs.getString("items", "") ?: "").split("|").filter { it.isNotEmpty() }.toSet()
        endings = (prefs.getString("endings", "") ?: "").split("|").filter { it.isNotEmpty() }.toSet()
        started = prefs.getBoolean("started", false)
    }

    private fun save() {
        prefs.edit()
            .putString("scene", sceneId)
            .putInt("hp", hp)
            .putString("items", items.joinToString("|"))
            .putString("endings", endings.joinToString("|"))
            .putBoolean("started", started)
            .apply()
    }
}
